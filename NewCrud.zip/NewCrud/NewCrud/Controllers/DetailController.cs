﻿using NewCrud.Database;
using NewCrud.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NewCrud.Controllers
{
    public class DetailController : Controller
    {
        // GET: Detail
        public ActionResult Index()
        {
            crudEntities obj = new crudEntities();
            var res = obj.employees.ToList();
            List<Employee> list = new List<Employee>();
            foreach (var employee in res) 
            {
                list.Add(new Employee()
                {
                    Id = employee.Id,
                    Name = employee.Name,
                    Field = employee.Field,
                    Salary = employee.Salary,
                });
            }
            return View(list);
        }

        public ActionResult Create() 
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(employee e)
        {
            if (ModelState.IsValid)
            {
                crudEntities obj = new crudEntities();
                obj.employees.Add(e);
                int a = obj.SaveChanges();
                if (a > 0)
                {
                    ViewBag.InsertMessage = "<script>alert('Data Inserted !!')</script>";
                }
            }
                return RedirectToAction("Index");
            
        }

        public ActionResult Delete(int id)
        {
            crudEntities obj = new crudEntities();
           var res = obj.employees.Where(m=>m.Id == id).First();
            obj.employees.Remove(res);
            obj.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int id)
        {
            crudEntities obj = new crudEntities();
            var res = obj.employees.Where(m=> m.Id == id).First();
            return View(res);
        }

        [HttpPost]
        public ActionResult Edit(employee e)
        {
            crudEntities obj = new crudEntities();
            obj.Entry(e).State = System.Data.Entity.EntityState.Modified;
            obj.SaveChanges();
            ModelState.Clear();
            return RedirectToAction("Index");
        }
    }
}